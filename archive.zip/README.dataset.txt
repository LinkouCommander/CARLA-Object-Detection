# CARLA Object Detection Model > carla_processed_dataset
https://universe.roboflow.com/carla-m1eac/carla-object-detection-model-8usui

Provided by a Roboflow user
License: CC BY 4.0

